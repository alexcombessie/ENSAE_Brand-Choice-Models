Andrew Ching, T�lin Erdem and Michael Keane, "The Price Consideration
Model of Brand Choice", Journal of Applied Econometrics, Volume 24, No. 3,
2009, pp. 393-420.

This file explains how the data sets used in this paper are organized.

There are two data files: (i) ketchup_est_m.txt (for ketchup), and (ii) 
pbut_est_m.txt (peanut butter). The format of these two data files are 
the same. Both datasets are individual level panel data.

Both files are ASCII files in DOS format. They are zipped in the file
cek-data.zip. Unix/Linux users should use "unzip -a".

Source: A.C. Nielsen maintained by Chicago GSB
(http://research.chicagogsb.edu/marketing/databases/erim/index.aspx)

Number of observations: 314,417 for ketchup_est_m.txt and 236,351 for
pbut_est_m.txt. 

Data file size: 62906201 bytes for ketchup_est_m.txt and 47009171 bytes
for pbut_est_m.txt

There are 31 variables in each file. I explain the meaning of each 
variable as follows.

1. hhold_id - Household identification number

2. brand (0-5)

For pbut_est_m.txt (peanut butter),

0=no purchase
1=store brand
2=JIF
3=Peter Pan
4=Skippy
5=Other

For ketchup_est_m.txt (ketchup),

0=no purchase
1=Heinz
2=Hunt's
3=Del Monte
4=Store Brand
5=Other

3. i_obs - index for observations for the household

4. m_obs - the maximum number of observations for corresponding hhold_id

5. hhold_income - Household income (1 - 11)

   1=less than $5,000
   2=$5,000-9,999
   3=$10,000-14,999
   4=$15,000-19,999
   5=$20,000-24,999
   6=$25,000-29,999
   7=$30,000-34,999
   8=$35,000-39,999
   9=$40,000-44,999
   10=$45,000-49,999
   11=$50,000-59,999
   12=$60,000-74,999
   13=$75,000-$99,999
   14=$100,000 or more

6. hhold_members  Number of members in a household 

7. hhold_male_educ  Male head education (1 - 11)

   1=did not attend school
   2=some grade school
   3=graduate grade school
   4=some high school
   5=graduated high school
   6=some trade or business school
   7=graduated trade or business school
   8=some college
   9=graduated college
   10=attended graduate school
   11=post-graduate degree

8. hhold_female_educ  Female head education (1 - 11)

As above

9. erim_market (1 or 2)

1 Sioux Falls
2 Springfield

10. Store ID Store identification number

11. n_wk  the week that the household went to a store

12. ind_ft (0 or 1)

0 = none of the brand is feature in the flyer
1 = at least one brand is feature in the flyer

13. ind_dp (0 or 1)

0 = none of the brand is on display
1 = at least one brand is on display

14. Coupon_val ($) - Total value of coupon used (store coupons +
    manufacturer coupons)

15. Coupon_av (the average of coupon value by brand and week)

16. P1 - Price of brand 1 (for 32 oz)

17. P2 - Price of brand 2 (for 32 oz)

18. P3 - Price of brand 3 (for 32 oz)

19. P4 - Price of brand 4 (for 32 oz)

20. ft1 - feature dummy for brand 1 

21. ft2 - feature dummy for brand 2 

22. ft3 - feature dummy for brand 3 

23. ft4 - feature dummy for brand 4 

24. dp1 - feature dummy for brand 1 

25. dp2 - feature dummy for brand 2 

26. dp3 - feature dummy for brand 3 

27. dp4 - feature dummy for brand 4 

28. cp_av1 - coupon availability for brand 1 

29. cp_av2 - coupon availability for brand 2 

30. cp_av3 - coupon availability for brand 3 

31. cp_av4 - coupon availability for brand 4 



